#include <iostream>
using namespace std;

int pow(int a, int b){ //to calculate a^b where a >= 0
    if (b == 0) return 1;
    int n = a;
    for (int i = 0; i < b-1; i++){
        n*=a;
    }
    return n;
}

bool isPalindrome(int x){
    int digits = 0, cx = x, sum = 0;
    while(cx){ //check the number of digits of the integer
        cx/=10;
        digits++;
    }
    for (int i = 1; i <= digits; i++){ //reverse the digit and calculate
        int b = (x%(pow(10, i))/pow(10, i-1))*pow(10, digits-i);
        sum+=b;
    }
    return x==sum;
}

bool isProduct(int x){
    for (int i = 100; i <= 999; i++){
        for (int j = 100; j <= 999; j++){
            if(i*j==x) return true;
        }
    }
    return false;
}
int main(){
    int m, n, t;
    char opt;
    cin >> m >> n >> opt;
    switch(opt){ //check the required output 
        case 'p':
            for (int i = m; i <= n; i++){
                if (isPalindrome(i)){
                    cout << i << endl;
                }
            }
            break;
        case 't':
            for (int i = m; i <= n; i++){
                if (isProduct(i)){
                    cout << i << endl;
                }
            }
            break;
        case 'b':
            for (int i = m; i <= n; i++){
                if(isProduct(i) && isPalindrome(i)){
                    cout << i << endl;
                }
            }
            break;
    }
}
