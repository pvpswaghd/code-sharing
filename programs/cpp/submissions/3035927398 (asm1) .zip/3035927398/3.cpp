#include <iostream>

using namespace std;

const int MAXLEN = 50;  // max length for input sequence of characters
const int MAXKEY = 10;  // max length for key

const char dict[26] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O','P','Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
//to order the dictionary in lexicographical order
int checkDictIndex (char s){ //check the key of the letter
    if (s >= 'A' && s <= 'Z') return s-'A';
    return s-'a';
}

int main()
{
    // to store user inputs
    char s;             // 'e' for encryption, 'd' for decryption
    char text[MAXLEN];  // the sequence of characters to encrypt/decrypt
    char key[MAXKEY];   // the key

    cin >> s;
    char x;
    for (int i = 0; i < MAXLEN; i++){
        cin >> x;
        if (x == '!') break;
        text[i] = x;
    }
    int keySize;
    cin >> keySize;
    for (int i = 0; i < keySize; i++){
        cin >> key[i];
    }
    int y;
    for (int i = 0; i < strlen(text); i++){
       //(x+k)mod26 when s == 'e', and (x-k) may be a negative number
       //so an additional statement to make the array cyclic
       y = (s=='e') ? (checkDictIndex(text[i])+checkDictIndex(key[i%keySize]))%26 : ((checkDictIndex(text[i])-checkDictIndex(key[i%keySize]))%26) < 0 ? ((checkDictIndex(text[i])-checkDictIndex(key[i%keySize]))%26) + 26 : (checkDictIndex(text[i])-checkDictIndex(key[i%keySize]))%26 ;
       if (text[i] >= 'A' && text[i] <= 'Z') text[i] = (char) (dict[y]+32);
       else if (text[i] >= 'a' && text[i] <= 'z') text[i] = dict[y];
       else continue;
    }
    for (int i = 0; i < strlen(text); i++){
        cout << text[i]; //print the text
    }
    cout << '!' << endl;
    return 0;
}
