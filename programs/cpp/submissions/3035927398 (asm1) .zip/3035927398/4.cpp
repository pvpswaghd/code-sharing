#include <iostream>
#include <cstdlib>      // for calling srand(), rand()
#include <ctime>        // for calling time()

#define SPADE   "\xE2\x99\xA0"
#define CLUB    "\xE2\x99\xA3"
#define HEART   "\xE2\x99\xA5"
#define DIAMOND "\xE2\x99\xA6"
#define NUMCARDS  5

using namespace std;

int number[NUMCARDS], symbol[NUMCARDS];


int findMax(int a, int b){ //a self-written function to replace std::max()
    if(a>b) return a;
    return b;
}

int findMin(int a, int b){ //a self-written function to replace std::max()
    if (b>a) return a;
    return b;
}
bool IsFourOfAKind(int cards[]){
    int count[13]; //count the number of occurence of each card into an array
    for (int i = 0; i < 13; i++){
        count[i] = 0;
    }
    int t = NUMCARDS;
    while(t--) count[cards[t]%13]+=1;
    int maxc = 0;
    for (int i = 0; i < 13; i++){
        maxc = findMax(maxc, count[i]); //find the maximum occurence inside the array
    }
    return (maxc==4); //if its four of a kind (which maxc = 4), then it will return 1

}

bool IsFullHouse(int cards[]){
    int count[13];
    for (int i = 0; i < 13; i++){
        count[i] = 0;
    }
    int t = NUMCARDS;
    while(t--) count[cards[t]%13]+=1;
    int maxc = 0;
    for (int i = 0; i < 13; i++){
        maxc = findMax(maxc, count[i]);
    } //since maximum occurence is 3, we have to find if there's a pair
    for (int i = 0; i < 13; i++){
        if (count[i] == 2 && maxc == 3) return 1;
    }
    return 0; //default
}

bool IsFlush(int cards[]){
    //the maximum and the minimum card for cards that are the same rank should not exceed 13.
    //therefore finding the maximum and the minimum raw value could determine if its flush.
    int minc = cards[0], maxc = cards[0];
    for (int i = 1; i < NUMCARDS; i++){
        minc = findMin(minc, cards[i]);
    }
    for (int i = 1; i < NUMCARDS; i++){
        maxc = findMax(maxc, cards[i]);
    }
    if ((maxc-minc) <= 12) return true;
    return false;
}

bool IsThreeOfAKind(int cards[]){
    //same concept as four of its kind
    int count[13];
    for (int i = 0; i < 13; i++){
        count[i] = 0;
    }
    int t = NUMCARDS;
    while(t--) count[cards[t]%13]+=1;
    int maxc = 0;
    for (int i = 0; i < 13; i++){
        maxc = findMax(maxc, count[i]);
    }
    return (maxc==3);


}

bool IsTwoPair(int cards[]){
    int count[13];
    for (int i = 0; i < 13; i++){
        count[i] = 0;
    }
    int t = NUMCARDS;
    while(t--) count[cards[t]%13]+=1;
    int maxc = 0;
    //first it checks whether there are a pair
    //then it checks if it meets another pair
    for (int i = 0; i < 13; i++){
        if(maxc == 2 && maxc == count[i]) return 1;
        maxc = findMax(maxc, count[i]);

    }
    return 0; //default statement
}

bool IsOnePair(int cards[]){
    int count[13];
    for (int i = 0; i < 13; i++){
        count[i] = 0;
    }
    int t = NUMCARDS;
    while(t--) count[cards[t]%13]+=1;
    int maxc = 0;
    for (int i = 0; i < 13; i++){
        maxc = findMax(maxc, count[i]);
    }
    return (maxc==2); //same concept as four of its kind
}

void setSym(int cards[]){
    //modulo could find the cards' raw values
    //divide could find the cards' rank
    for (int i = 0; i < NUMCARDS; i++){
        number[i] = cards[i]%13;
        symbol[i] = cards[i]/13;
    }
}

void PrintHand(int cards[]){
    setSym(cards);
    for (int i = 0; i < 5; i++){
        switch(number[i]){
            case 0:
                cout << "A";
                break;
            case 10: //special display for JQK
                cout << "J";
                break;
            case 11:
                cout << "Q";
                break;
            case 12:
                cout << "K";
                break;
            default:
                cout << number[i]+1;
                break;
        }
        switch(symbol[i]){
            case 0:
                cout << SPADE;
                break;
            case 1:
                cout << HEART;
                break;
            case 2:
                cout << CLUB;
                break;
            case 3:
                cout << DIAMOND;
        }
        if (i==4) continue;
        else cout << " ";
    }
    cout << endl;
}

void DealHand(int cards[]){
    int x;
    cin >> x;
    srand(x);
    for (int i = 0; i < 5; i++) cards[i] = rand()%52;
    PrintHand(cards);
    if(IsFourOfAKind(cards)){ //set reference number for different situation
        x = 0;
    }
    else if (IsFullHouse(cards)){
        x = 1;
    }
    else if (IsFlush(cards)){
        x = 2;
    }
    else if (IsThreeOfAKind(cards)){
        x = 3;
    }
    else if (IsTwoPair(cards)){
        x = 4;
    }
    else if (IsOnePair(cards)){
        x = 5;
    }
    else x = 6; //a default of x = 6 is setted
    switch(x){//display the result
        case 0:
            cout << "four of a kind" << endl;
            break;
        case 1:
            cout << "full house" << endl;
            break;
        case 2:
            cout << "flush" << endl;
            break;
        case 3:
            cout << "three of a kind" << endl;
            break;
        case 4:
            cout << "two pair" << endl;
            break;
        case 5:
            cout << "one pair" << endl;
            break;
        case 6:
            cout << "others" << endl;
    }
}

int main()
{
    int hand[NUMCARDS];   // declare an array of 5 integers to store a hand
    DealHand(hand);
    return 0;
}
