#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

const double e=2.72;

// IMPORTANT:  Do NOT change any of the function headers
//             It means that you will need to use the function headers as is

// Function: sigmoid activation function
// Input: double x: the input of sigmoid activation function
// Ouput: the output of sigmoid activation function
double sigmoid(double x)
{
    return (1/(1+pow(1/e, x)));
}

// Function: tanh activate function
// Input: double x: the input of tanh activation function
// Ouput: double: the output of tanh activation function.
double tanh(double x)
{
    return 2*(sigmoid(2*x))-1;
}

// Function: compute the next hidden value in an RNN cell
// Input: double x: current input value
//        double h: current hidden status in RNN cell
// Ouput: double: next hidden value in RNN cell
double ComputeH(double x, double h)
{
    return tanh(0.5*x-2*h);
}

// Function: compute the output value at current time step
// Input: double x: current input value
//        double h: current hidden status in RNN cell
// Ouput: double: current output value
double ComputeO(double x, double h)
{
    return sigmoid(0.1*x+1.5*h);
}

// Function: print the values stored in a 1D-array to screen
// Input: double xs[100]: the value of the sequence
//        int seq_len: the length of the sequence
void PrintSeqs(double xs[100], int seq_len)
{
    for (int i = 0; i < seq_len; i++){ //std::fixed is to add additional 0 to those who doesn't have 10 decimal space
        cout << fixed << setprecision(10) << xs[i] << " ";
    }
    cout << endl;
}

// Function: main function
int main()
{
    int length; double initialH; //initialH = h_0
    cin >> length;
    setprecision(10);
    cin >> initialH;
    setprecision(10);
    double xseq[100], hseq[100], oseq[100];
    for (int i = 0; i < length; i++){
        cin >> xseq[i];
    }
    oseq[0] = ComputeO(xseq[0], initialH);
    hseq[0] = ComputeH(xseq[0], initialH);
    for (int i = 1; i < length; i++){
        oseq[i] = ComputeO(xseq[i], hseq[i-1]);
        hseq[i] = ComputeH(xseq[i], hseq[i-1]);
    }
    PrintSeqs(hseq, length);
    PrintSeqs(oseq, length);
}
